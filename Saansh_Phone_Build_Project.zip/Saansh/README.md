# Saansh Android App

This is an Android Studio project wrapping the NIFTY Options Strategy Lab in a native Android WebView.

## Important trading limitation
This app is a paper-trading/backtesting research prototype only. It does not fetch live market data, connect to a broker, or place live orders. The current backtest uses the underlying index as a simplified proxy and does not model actual option premiums, Greeks, implied volatility, expiry payoffs, or contract selection. No strategy can guarantee profit or avoid all losses.

## Build the APK
1. Install Android Studio on a computer and install Android SDK Platform 35.
2. Extract this folder.
3. In Android Studio choose **Open** and select the `Saansh` folder.
4. Allow Gradle sync to finish. Use JDK 17 if prompted.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. Android Studio will show the generated APK location, typically `app/build/outputs/apk/debug/app-debug.apk`.
7. To make a release APK, use **Build > Generate Signed Bundle / APK** and follow Android Studio's signing flow.

## Project details
- App label: Saansh
- Package: `com.saansh.tradingbot`
- Minimum Android version: Android 6.0 (API 23)
- Strategy UI: bundled locally in `app/src/main/assets/index.html`
- Network permission: not requested; this version has no broker or live market connection.

Keep the APK private if you later add credentials. Broker API secrets should never be embedded in the Android app; use a secure backend for any future broker integration.
